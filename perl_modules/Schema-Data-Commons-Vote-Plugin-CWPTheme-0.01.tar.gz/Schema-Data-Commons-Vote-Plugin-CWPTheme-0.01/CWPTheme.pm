package Schema::Data::Commons::Vote::Plugin::CWPTheme;

use base qw(Schema::Data::Commons::Vote::Plugin::Theme);
use strict;
use warnings;

use Readonly;
use Unicode::UTF8 qw(decode_utf8);

Readonly::Array our @COMMONS_IMAGES => (

	# Czech Wiki Photo 2021
	decode_utf8('Bachyně se selátky.jpg'),
	decode_utf8('Karlštejn in winter.jpg'),
	'211003 Hody Vacenovice 1246.jpg',
	decode_utf8('Dlask tlustozobý.jpg'),

	# Czech Wiki Photo 2020
	'200913 Hody V Bilovice Foto Vit Svajcr 1958.jpg',
	decode_utf8('Ledňáček-říční.jpg'),
	decode_utf8('Barokní sochy v Růžové zahradě děčínského zámku.jpg'),
	'200913 Hody V Bilovice Foto Vit Svajcr 2443.jpg',

	# Czech Wiki Photo 2019
	'Ashley Wallbridge, Beats for Love 2019 07.jpg',
	decode_utf8('Daniel Souček U21 Czech Republic vs Greece 10-10-2019.jpg'),
	decode_utf8('Železniční trať v Ledči nad Sázavou 01.jpg'),
	'Main train station prague.jpg',
	'Jan preucil.jpg',
);

our $VERSION = 0.01;

sub _commons_images {
	my $self = shift;

	return @COMMONS_IMAGES;
}

sub _theme_variables {
	my $self = shift;

	return {
		'theme_name' => 'Czech Wiki Photo theme',
		'theme_shortcut' => 'cwp',
	};
}

1;

__END__
