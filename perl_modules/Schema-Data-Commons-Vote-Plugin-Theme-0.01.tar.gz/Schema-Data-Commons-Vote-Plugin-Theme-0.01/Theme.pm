package Schema::Data::Commons::Vote::Plugin::Theme;

use base qw(Schema::Data::Plugin);
use strict;
use warnings;

use Activity::Commons::Vote::Load;
use Backend::DB::Commons::Vote;
use Data::Commons::Vote::Theme;
use Data::Commons::Vote::ThemeImage;
use Error::Pure qw(err);
use Unicode::UTF8 qw(decode_utf8);

our $VERSION = 0.01;

sub load {
	my ($self, $variables_hr) = @_;

	my $backend = Backend::DB::Commons::Vote->new(
		'schema' => $self->{'schema'},
	);

	my $creator = $backend->fetch_person({
		'email' => $variables_hr->{'creator_email'},
		'name' => $variables_hr->{'creator_name'},
		'wm_username' => $variables_hr->{'creator_wm_username'},
	});

	if (! defined $creator) {
		err 'No creator.';
	}

	my $load = Activity::Commons::Vote::Load->new(
		'backend' => $backend,
		'creator' => $creator,
		'verbose_cb' => $self->{'verbose_cb'},
	);

	my $theme_variables_hr = $self->_theme_variables;
	my $theme = $backend->save_theme(
		Data::Commons::Vote::Theme->new(
			'created_by' => $creator,
			'name' => $theme_variables_hr->{'theme_name'},
			'shortcut' => $theme_variables_hr->{'theme_shortcut'},
		),
	);
	foreach my $commons_image ($self->_commons_images) {
		my $image = $load->load_commons_image($commons_image);

		$backend->save_theme_image(
			Data::Commons::Vote::ThemeImage->new(
				'created_by' => $creator,
				'theme_id' => $theme->id,
				'image' => $image,
			),
		);
	}

	return;
}

sub supported_versions {
	my $self = shift;

	return (
		'0.01',
	);
}

sub _commons_images {
	my $self = shift;

	# No images in abstract class.
	return ();
}

sub _theme_variables {
	my $self = shift;

	return {
		'theme_name' => 'Default theme',
		'theme_shortcut' => 'default',
	};
}

1;

__END__
