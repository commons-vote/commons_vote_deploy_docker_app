package Schema::Data::Foo::0_1_1;

1;
