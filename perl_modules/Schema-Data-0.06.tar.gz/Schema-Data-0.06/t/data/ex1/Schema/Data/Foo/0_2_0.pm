package Schema::Data::Foo::0_2_0;

1;
