package Schema::Data::Foo::0_1_0;

1;
