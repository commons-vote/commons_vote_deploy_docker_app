package Schema::Foo::0_1_1;

1;
