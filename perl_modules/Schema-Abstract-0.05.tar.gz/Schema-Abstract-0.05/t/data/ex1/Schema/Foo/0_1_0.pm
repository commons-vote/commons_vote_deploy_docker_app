package Schema::Foo::0_1_0;

1;
